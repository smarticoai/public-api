import { ProtocolResponse } from "../Base/ProtocolResponse";

export interface JackpotsOptoutResponse extends ProtocolResponse {

}