interface JackpotPublicMeta {
    name: string;
    description: string;
    image_url: string;
}


export { JackpotPublicMeta }