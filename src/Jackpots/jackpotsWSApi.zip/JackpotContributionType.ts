enum JackpotContributionType {
    Fixed = 1,
    Percentage = 2
}


export { JackpotContributionType }