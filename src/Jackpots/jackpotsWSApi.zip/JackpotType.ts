

enum JackpotType {
    Main = 1
}


export { JackpotType }