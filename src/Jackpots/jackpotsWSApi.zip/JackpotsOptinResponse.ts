import { ProtocolResponse } from "../Base/ProtocolResponse";

export interface JackpotsOptinResponse extends ProtocolResponse {

}